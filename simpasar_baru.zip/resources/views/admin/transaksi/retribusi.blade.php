@extends('layouts.app')

@section('content')
<h3><i class="fa fa-angle-right"></i> Retribusi</h3>
    <div class="row">
      <div class="col-md-12 text-center">
        <h3>Tidak ada retribusi hari ini!</h3>
      </div>
    </div>
@endsection
