@extends('layouts.app')

@section('content')
    <h1>Laporan</h1>
@endsection