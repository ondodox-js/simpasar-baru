<?php 

    return[
        'nama_pengguna' => env('ADMIN_USER'),
        'kata_sandi' => env('ADMIN_PASS')
    ];
?>