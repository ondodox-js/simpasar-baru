MAPPING SITE

-   Admin
-   -   Dashboard
-
-   -   Data Master
-   -   -   Data Pedagang
-   -   -   Data Retribusi
-   -   -   Data Sewa
-   -   -   Data Produk Komoditas
-
-   -   Data Transaksi
-   -   -   Transaksi Pembayaran Sewa
-   -   -   Transaksi Pembayaran Retribusi
-
-   -   Laporan
-
-   -   Artikel
-   -   -   Tampa Artikel
-   -   -   Lihat Artikel

-   Landing Page -> Pedagang
-   -   Beranda
-   -   Harga Produk Komoditas
-   -   Lapak
-   -   Pembayaran Retribusi
-   -   Pembayaran Sewa
-   -   Layout Artikel
-   -   Login/Logout

//resep ungkep ayam
5 siung bawang putih (gadang)
8 sing bawang merah (gadang)
jahe 1 1/2 jempol
lengkuas 3 jempol

garam 1 sendok
rayco 1bkgs
sarai sebatang
daun salam 3buah
daun limau 4buah
daun kunyik 1buah
sapas ayam
