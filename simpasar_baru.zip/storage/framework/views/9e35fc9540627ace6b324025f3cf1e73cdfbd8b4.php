

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Data Retribusi</h3>
    <div class="row">
      <?php if(count($retribusis) > 0): ?>
      <div class="col-md-12">
          <div class="text-right mb">
            <a href="<?php echo e(route('admin.retribusi.tambah')); ?>" class="btn btn-theme">Retribusi baru</a>
          </div>
          <div class="content-panel">
              <table class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Layanan</th>
                    <th>Biaya awal</th>
                    <th>Persentase kenaikan biaya</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $retribusis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retribusi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <form action="<?php echo e(route('admin.retribusi.destroy', ['id' => $retribusi->id_retribusi])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($retribusi->layanan); ?></td>
                      <td><?php echo e($retribusi->biaya_awal); ?></td>
                      <td><?php echo e($retribusi->kenaikan_biaya . " %"); ?></td>
                      <td>
                        <button class="btn btn-success btn-xs"><i class="fa fa-dollar"></i></button>
                        <a href="<?php echo e(route('admin.retribusi.edit', ['id' => $retribusi->id_retribusi])); ?>" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                        <button type="submit" class="btn btn-danger btn-xs" onclick="return confirm('Hapus <?php echo e($retribusi->layanan); ?> ?')"><i class="fa fa-trash-o "></i></button>
                      </td>
                    </tr>
                  </form>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
          </div>
      </div> 
      <?php else: ?>
      <div class="col-md-12 text-center">
        <h3>Data retribusi belum ada!</h3>
        <a href="<?php echo e(route('admin.retribusi.tambah')); ?>" class="btn btn-theme">Retribusi baru</a>
      </div>
      <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\simpasar-baru\resources\views/admin/retribusi/index.blade.php ENDPATH**/ ?>