

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Data Pedagang Terdaftar</h3>
    <div class="row">
      <?php if(count($pedagangs) > 0): ?>
      <div class="col-md-12">
          <div class="text-right mb">
            <a href="<?php echo e(route('admin.pedagang.tambah')); ?>" class="btn btn-theme">Pedagang baru</a>
          </div>
          <div class="content-panel">
              <table class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>NIK</th>
                    <th>Nama lengkap</th>
                    <th>No handphone</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $pedagangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedagang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <form action="<?php echo e(route('admin.pedagang.destroy', ['id' => $pedagang->id_pedagang])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($pedagang->nik); ?></td>
                      <td><?php echo e($pedagang->nama_lengkap); ?></td>
                      <td><?php echo e($pedagang->no_hp); ?></td>
                      <td>
                        <button class="btn btn-success btn-xs"><i class="fa fa-eye"></i></button>
                        <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                      </td>
                    </tr>
                  </form>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
          </div>
      </div>
      <?php else: ?>
      <div class="col-md-12 text-center">
        <h3>Data pedagang belum ada!</h3>
        <a href="<?php echo e(route('admin.pedagang.tambah')); ?>" class="btn btn-theme">Pedagang baru</a>
      </div>
      <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\simpasar-baru\resources\views/admin/pedagang/index.blade.php ENDPATH**/ ?>