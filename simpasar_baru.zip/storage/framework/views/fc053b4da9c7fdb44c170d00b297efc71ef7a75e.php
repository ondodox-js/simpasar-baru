

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Data Barang Komoditas Pokok</h3>
    <div class="row">
        <div class="col-md-12">
            <div class="content-panel">
                <table class="table">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>Username</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>Mark</td>
                      <td>Otto</td>
                      <td>@mdo</td>
                    </tr>
                  </tbody>
                </table>
              </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\SIMPASARBANJAR\SIMPASARBANJAR\resources\views/admin/barang/index.blade.php ENDPATH**/ ?>