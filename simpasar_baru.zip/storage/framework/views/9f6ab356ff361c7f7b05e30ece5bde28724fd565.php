

<?php $__env->startSection('content'); ?>
    <h3><i class="fa fa-angle-right"></i> Penambahan Data Pedagang Baru</h3>
    <form class="contact-form php-mail-form" role="form" action="<?php echo e(route('admin.pedagang.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row mt">
        <div class="col-lg-6 col-md-6 col-sm-6">
            <h4 class="title">Data pedagang</h4>
            <div id="message"></div>
            <div class="contact-form php-mail-form">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="text" name="nik" class="form-control" placeholder="Nomor Induk Kependudukan..." data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                    <div class="validate"></div>
                </div>
                <div class="form-group">
                    <input type="text" name="namaLengkap" class="form-control" placeholder="Nama lengkap..." data-rule="minlen:4" data-msg="Please enter at least 4 chars">
                    <div class="validate"></div>
                </div>
                <div class="form-group">
                    <input type="text" name="noHp" class="form-control" placeholder="(+62) ..." data-rule="number" data-msg="Please enter a valid email">
                    <div class="validate"></div>
                </div>
                <div class="form-group">
                    <textarea class="form-control" name="alamat" placeholder="Alamat..." rows="5" data-rule="required" data-msg="Please write something for us"></textarea>
                    <div class="validate"></div>
                </div>
            </div>
        </div>

        <div class="col-lg-6 col-md-6 col-sm-6">
            <h4 class="title">Data sewa</h4>
            <div id="message"></div>
            <div class="form-group">
                <input type="number" name="periode" class="form-control" placeholder=".../bulan" data-rule="number" data-msg="Please enter a valid email">
                <div class="validate"></div>
            </div>
            <div class="form-group">
                <select class="form-control" name="idLapak">
                    <option selected disabled>Lapak atau kios :</option>
                    <?php $__currentLoopData = $lapaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lapak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($lapak->id_lapak); ?>"><?php echo e($lapak->posisi); ?> - <?php echo e($lapak->luas); ?> m³ - Rp. <?php echo e($lapak->harga_sewa); ?> / bulan</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="loading"></div>
            <div class="error-message"></div>
            <div class="sent-message">Your message has been sent. Thank you!</div>

            <div class="form-send">
                <button type="submit" class="btn btn-large btn-primary">Berikutnya</button>
            </div>

                <!-- contact_details -->
        </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\SIMPASARBANJAR\SIMPASARBANJAR\resources\views/admin/pedagang/tambah.blade.php ENDPATH**/ ?>