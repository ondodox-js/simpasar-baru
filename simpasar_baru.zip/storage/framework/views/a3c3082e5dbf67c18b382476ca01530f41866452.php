

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Pemesanan</h3>
    <div class="row">
      <?php if(count($pemesanans) > 0): ?>
      <div class="col-md-12">
        <div class="content-panel">
            <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Kode pembayaran</th>
                  <th>Nama penyewa</th>
                  <th>Nomor lapak</th>
                  <th>Jumlah bayar</th>
                  <th>Tanggal pemesanan</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $pemesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    $label_class = $pemesanan->status ? 'label-success' : 'label-danger'    
                  ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($pemesanan->kode_pembayaran); ?></td>
                    <td><?php echo e($pemesanan->nama_lengkap); ?></td>
                    <td><?php echo e($pemesanan->posisi); ?></td>
                    <td><?php echo e($pemesanan->jumlah_bayar); ?></td>
                    <td><?php echo e(date($pemesanan->tanggal_transaksi)); ?></td>
                    <td class="text-center">
                        <span class="label <?php echo e($label_class); ?> pull-right"><?php echo e($pemesanan->keterangan); ?></span>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
      </div>  
      <?php else: ?>
      <div class="col-md-12 text-center">
        <h3>Tidak ada pemesansn hari ini!</h3>
      </div>
      <?php endif; ?>
      
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\simpasar-baru\resources\views/admin/transaksi/index.blade.php ENDPATH**/ ?>