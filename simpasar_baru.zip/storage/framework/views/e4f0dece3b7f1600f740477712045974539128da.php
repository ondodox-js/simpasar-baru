

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Artikel belum tersedia</h3>
    <div class="row">
      <div class="col-md-12 text-center">
        <h3>Artikel belum ada!</h3>
        <a href="" class="btn btn-theme">Artikel baru</a>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\SIMPASARBANJAR\SIMPASARBANJAR\resources\views/admin/artikel/index.blade.php ENDPATH**/ ?>