

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Artikel belum tersedia</h3>
    <div class="row">
      <?php if(count($artikels) > 0): ?>
      <div class="col-md-12">
        <div class="text-right mb">
          <a href="<?php echo e(route('admin.artikel.tambah')); ?>" class="btn btn-theme">Artikel baru</a>
        </div>
        <div class="content-panel">
            <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Judul</th>
                  <th>Link</th>
                  <th>Deskripsi</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(route('admin.artikel.destroy', ['id' => $artikel->id_artikel])); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('delete'); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($artikel->judul); ?></td>
                    <td><?php echo e($artikel->link); ?></td>
                    <td><?php echo e($artikel->deskripsi); ?></td>
                    <td>
                      <button class="btn btn-success btn-xs"><i class="fa fa-eye"></i></button>
                      <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                    </td>
                  </tr>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
      </div>  
      <?php else: ?>
      <div class="col-md-12 text-center">
        <h3>Artikel belum ada!</h3>
        <a href="<?php echo e(route('admin.artikel.tambah')); ?>" class="btn btn-theme">Artikel baru</a>
      </div>
      <?php endif; ?>
      
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\simpasar-baru\resources\views/admin/artikel/index.blade.php ENDPATH**/ ?>