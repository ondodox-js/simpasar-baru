

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Data Lapak atau Kios</h3>
    <div class="row">
        <?php if(count($lapaks) > 0): ?>
        <div class="col-md-12">
          <div class="text-right mb">
            <a href="<?php echo e(route('admin.lapak.tambah')); ?>" class="btn btn-theme">Lapak baru</a>
          </div>
          <div class="content-panel">
              <table class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Posisi</th>
                    <th>Luas</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $lapaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lapak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <form action="<?php echo e(route('admin.lapak.destroy', ['id' => $lapak->id_lapak])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($lapak->posisi); ?></td>
                      <td><?php echo e($lapak->luas); ?> cm</td>
                      <td><?php echo e($lapak->status ? 'Tersedia' : 'Disewakan'); ?></td>
                      <td>
                        <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                        <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                        <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                      </td>
                    </tr>
                  </form>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
          </div>
        </div>
        <?php else: ?>
        <div class="col-md-12 text-center">
          <h3>Data lapak atau kios belum ada!</h3>
          <a href="<?php echo e(route('admin.lapak.tambah')); ?>" class="btn btn-theme">Lapak baru</a>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\simpasar-baru\resources\views/admin/lapak/index.blade.php ENDPATH**/ ?>