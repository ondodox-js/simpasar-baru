

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Data Penyewa Terdaftar</h3>
    <div class="row">
      <?php if(count($sewas) > 0): ?>
      <div class="col-md-12">
          <div class="content-panel">
              <table class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nomor lapak atau kios</th>
                    <th>Nama pedagang</th>
                    <th>Mulai sewa</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $sewas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sewa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <form action="<?php echo e(route('admin.pedagang.destroy', ['id' => $sewa->id_sewa])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($sewa->posisi); ?></td>
                      <td><?php echo e($sewa->nama_lengkap); ?></td>
                      <td><?php echo e($sewa->tanggal_sewa); ?></td>
                      <td>
                        <button class="btn btn-success btn-xs"><i class="fa fa-eye"></i></button>
                        <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
                        <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                      </td>
                    </tr>
                  </form>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
          </div>
      </div>
      <?php else: ?>
      <div class="col-md-12 text-center">
        <h3>Penyewa belum ada!</h3>
      </div>       
      <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\SIMPASARBANJAR\SIMPASARBANJAR\resources\views/admin/sewa/index.blade.php ENDPATH**/ ?>