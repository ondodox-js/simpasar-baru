

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Data Transaksi Komoditas Pokok</h3>
    <div class="row">
      <div class="col-md-12 text-center">
        <h3>Data transaksi belum ada!</h3>
        <a href="" class="btn btn-theme">Transaksi baru</a>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\SIMPASARBANJAR\SIMPASARBANJAR\resources\views/admin/transaksi/index.blade.php ENDPATH**/ ?>