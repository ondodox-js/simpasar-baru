

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Retribusi</h3>
    <div class="row">
      <div class="col-md-12 text-center">
        <h3>Tidak ada retribusi hari ini!</h3>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\simpasar-baru\resources\views/admin/transaksi/retribusi.blade.php ENDPATH**/ ?>