

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Data Kategori Komoditas Pokok</h3>
    <div class="row">
      <?php if(count($kategoris) > 0): ?>
      <div class="col-md-12">
          <div class="text-right mb">
            <a href="<?php echo e(route('admin.kategori.tambah')); ?>" class="btn btn-theme">Tambah kategori</a>
          </div>
          <div class="content-panel">
            <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Nama kategori</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(route('admin.kategori.destroy', ['id' => $kategori->id_kategori])); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('delete'); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($kategori->nama_kategori); ?></td>
                    <td>
                      <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
                      <a href="<?php echo e(route('admin.kategori.edit', ['id' => $kategori->id_kategori])); ?>" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                      <button type="submit" onclick="return confirm('Hapus <?php echo e($kategori->nama_kategori); ?> ?')" class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
                    </td>
                  </tr>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
      </div>
      <?php else: ?>
      <div class="col-md-12 text-center">
        <h3>Data kategori belum ada!</h3>
        <a href="<?php echo e(route('admin.kategori.tambah')); ?>" class="btn btn-theme">Kategori baru</a>
      </div>
      <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\SIMPASARBANJAR\SIMPASARBANJAR\resources\views/admin/kategori/index.blade.php ENDPATH**/ ?>