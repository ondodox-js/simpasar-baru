

<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i> Pemesanan</h3>
    <div class="row">
      <?php if(count($pemesanans) > 0): ?>
      <div class="col-md-12">
        <div class="content-panel">
            <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Judul</th>
                  <th>Link</th>
                  <th>Deskripsi</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $pemesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($pemesanan->kode_pembayaran); ?></td>
                    <td><?php echo e($pemesanan->jumlah_bayar); ?></td>
                    <td><?php echo e(date($pemesanan->tanggal_transaksi)); ?></td>
                    <td>
                      <?php if(!$pemesanan->status): ?>
                        <span class="label label-danger pull-right">pending</span>
                      <?php else: ?>
                        <span class="label label-success pull-right">success</span>             
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
      </div>  
      <?php else: ?>
      <div class="col-md-12 text-center">
        <h3>Tidak ada pemesansn hari ini!</h3>
      </div>
      <?php endif; ?>
      
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\free\SIMPASARBANJAR\SIMPASARBANJAR\resources\views/admin/transaksi/index.blade.php ENDPATH**/ ?>